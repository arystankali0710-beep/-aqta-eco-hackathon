import { createFileRoute } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDown,
  ArrowRight,
  Camera,
  Check,
  ChevronRight,
  CircleDot,
  Droplets,
  Image as ImageIcon,
  MapPin,
  Menu,
  Mic,
  Radio,
  Sparkles,
  Volume2,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AQTA — Ақтаудағы су ағуын хабарлау" },
      {
        name: "description",
        content:
          "Ақтау тұрғындарына су ағуын хабарлап, AI талдауын және жөндеу мәртебесін бақылауға арналған интерактивті платформа.",
      },
      { property: "og:title", content: "AQTA — Ақтаудағы су қауіпсіздігі" },
      {
        property: "og:description",
        content: "Су ағуын хабарлау, AI арқылы бағалау және қалалық картадан бақылау.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Lang = "kk" | "ru";
type Severity = "high" | "medium" | "low" | "resolved";

const copy = {
  kk: {
    nav: ["Қалай жұмыс істейді", "Қызметтерге", "AI талдау"],
    loss: "Ақтауда тұщытылған судың кранға жетпей жоғалатын үлесі",
    titleA: "Ақта: Ақтау қаласының су қауіпсіздігі —",
    titleB: "интерактивті картада",
    lead: "Лезде хабарлау: Байқаған ағулар мен төтенше жағдайларды бір кликпен автоматты түрде тіркеңіз.",
    report: "Ағу туралы хабарлау",
    map: "Интерактивті картаға өту",
    eyebrow: "Үш қадам — бір ортақ жүйе",
    how: "Қалай жұмыс істейді",
    precedent: "Әлемдік тәжірибе",
    ai: "AI нені көреді және естиді",
    dashboard: "Өтінімдер картасы · бүгін",
    now: "Неліктен дәл қазір маңызды",
    prototype: "Прототип · Ақтау су ағуы қолданбасы",
    tagline: "Ақта — енді үнсіз жоғалмайтын су",
  },
  ru: {
    nav: ["Как это работает", "Для служб", "AI-анализ"],
    loss: "опреснённой воды в Актау теряется, не доходя до крана",
    titleA: "Aqta: водная безопасность Актау —",
    titleB: "на интерактивной карте",
    lead: "Каждая заявка жителя об утечке фиксируется. Инциденты в микрорайонах 7 и 16 уже видны на карте.",
    report: "Сообщить об утечке",
    map: "Открыть интерактивную карту",
    eyebrow: "Три шага — одна общая система",
    how: "Как это работает",
    precedent: "Мировой прецедент",
    ai: "Что видит и слышит AI",
    dashboard: "Карта заявок · сегодня",
    now: "Почему это важно сейчас",
    prototype: "Прототип · приложение по утечкам воды в Актау",
    tagline: "Ақта — вода, которую больше не теряют молча",
  },
};

const incidents: Array<{
  id: number;
  severity: Severity;
  district: string;
  title: string;
  meta: string;
  x: string;
  y: string;
}> = [
  { id: 2419, severity: "high", district: "7 мкр", title: "Порыв водовода у школы", meta: "12 мин · 6 совпадений", x: "30%", y: "35%" },
  { id: 2416, severity: "medium", district: "14 мкр", title: "Вода у теплового узла", meta: "28 мин · фото", x: "65%", y: "26%" },
  { id: 2412, severity: "low", district: "3 мкр", title: "Мокрый участок у дороги", meta: "43 мин · аудио", x: "45%", y: "66%" },
  { id: 2405, severity: "resolved", district: "7 мкр", title: "Магистральный порыв устранён", meta: "Закрыто в 18:42", x: "22%", y: "55%" },
  { id: 2398, severity: "resolved", district: "16 мкр", title: "Ремонт газовой линии · контекст", meta: "Передано 104", x: "77%", y: "61%" },
];

const severityLabel: Record<Severity, string> = {
  high: "Высокий",
  medium: "Средний",
  low: "Низкий",
  resolved: "Закрыт",
};

const getHowCards = (lang: Lang): Array<{ num: string; title: string; text: string; icon: LucideIcon }> => [
  { num: "01", title: lang === "kk" ? "Тұрғын тіркейді" : "Житель фиксирует", text: lang === "kk" ? "Фото, аудио немесе карта нүктесі — сырттан көрінетін кез келген белгі." : "Фото, аудио или точка на карте — всё, что можно заметить снаружи.", icon: Camera },
  { num: "02", title: lang === "kk" ? "AI бағалайды" : "AI оценивает", text: lang === "kk" ? "Ағу белгілерін, жақын өтінімдер тарихын, ауқымы мен шұғылдығын салыстырады." : "Сверяет признаки утечки, историю заявок рядом, масштаб и срочность.", icon: Sparkles },
  { num: "03", title: lang === "kk" ? "Бригада жіберіледі" : "Бригада выезжает", text: lang === "kk" ? "Басым өтінім тікелей қызмет кезегіне түседі, мәртебесі қолданбада көрінеді." : "Приоритетная заявка попадает в очередь службы, статус виден в приложении.", icon: Radio },
];

const getAiCards = (lang: Lang): Array<{ title: string; text: string; icon: LucideIcon }> => [
  { icon: ImageIcon, title: lang === "kk" ? "Кескін" : "Изображение", text: lang === "kk" ? "Жаңа ағуды жаңбырдан немесе көлік жуудан қалған шалшықтан ажыратады." : "Отличает свежую утечку от лужи после дождя или мойки машины." },
  { icon: Volume2, title: lang === "kk" ? "Дыбыс" : "Звук", text: lang === "kk" ? "Жертөле мен құдықтағы дыбысты қысымды құбыр ағуының акустикалық ізімен салыстырады." : "Сопоставляет аудио из подвала или люка с акустическим следом напорной утечки." },
  { icon: MapPin, title: lang === "kk" ? "Аудан контексті" : "Контекст района", text: lang === "kk" ? "Құбыр жасын және жақындағы өтінімдерді ескеріп, басымдықты өзгертеді." : "Учитывает возраст труб и недавние заявки рядом, повышая или снижая приоритет." },
];

function RippleButton({ children, onClick, outline = false }: { children: React.ReactNode; onClick: () => void; outline?: boolean }) {
  return (
    <Button
      onClick={onClick}
      className={`ripple-button h-auto min-h-12 rounded-full px-5 py-3 text-left text-sm font-semibold shadow-none ${outline ? "border border-primary/25 bg-transparent text-primary hover:bg-primary/5" : "bg-primary text-primary-foreground hover:bg-primary/95"}`}
    >
      <span>{children}</span><ArrowRight className="size-4" />
    </Button>
  );
}

function PhoneDemo({ lang }: { lang: Lang }) {
  const [step, setStep] = useState(1);
  const [capture, setCapture] = useState<"photo" | "audio">("photo");
  const [pin, setPin] = useState(false);
  const [note, setNote] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [audioUrl, setAudioUrl] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [mediaError, setMediaError] = useState("");
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (!isRecording) return;
    const timer = window.setInterval(() => setRecordingSeconds((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [isRecording]);

  useEffect(() => () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    if (audioUrl) URL.revokeObjectURL(audioUrl);
  }, [photoUrl, audioUrl]);

  const selectPhoto = (file?: File) => {
    if (!file) return;
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    setPhotoUrl(URL.createObjectURL(file));
    setMediaError("");
  };

  const startRecording = async () => {
    setMediaError("");
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setMediaError(lang === "kk" ? "Бұл браузер дыбыс жазуды қолдамайды." : "Этот браузер не поддерживает запись звука.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        if (audioUrl) URL.revokeObjectURL(audioUrl);
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      };
      setRecordingSeconds(0);
      recorder.start();
      setIsRecording(true);
    } catch {
      setMediaError(lang === "kk" ? "Микрофонға рұқсат беріңіз." : "Разрешите доступ к микрофону.");
    }
  };

  const stopRecording = () => {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    setIsRecording(false);
  };

  const next = () => setStep((value) => Math.min(3, value + 1));
  const reset = () => { setStep(1); setPin(false); setNote(""); setPhotoUrl(""); setAudioUrl(""); setRecordingSeconds(0); };
  return (
    <div id="report-demo" className="phone-shell" aria-label="Interactive leak report demo">
      <div className="phone-speaker" />
      <div className="flex items-center justify-between border-b border-border/70 px-5 pb-3 pt-5">
        <div className="flex items-center gap-2 font-semibold"><Droplets className="size-4 text-accent" />Aqta</div>
        <span className="text-xs text-muted-foreground">{step} / 3</span>
      </div>
      <div className="phone-progress"><span style={{ width: `${step * 33.333}%` }} /></div>
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div key="one" className="phone-content" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }}>
            <p className="phone-kicker">{lang === "kk" ? "Жаңа өтінім" : "Новая заявка"}</p>
            <h3>{lang === "kk" ? "Не байқадыңыз?" : "Что вы заметили?"}</h3>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={() => setCapture("photo")} className={`h-16 flex-col rounded-md shadow-none ${capture === "photo" ? "border-accent bg-accent/10" : ""}`}><Camera />Фото</Button>
              <Button variant="outline" onClick={() => setCapture("audio")} className={`h-16 flex-col rounded-md shadow-none ${capture === "audio" ? "border-accent bg-accent/10" : ""}`}><Mic />Аудио</Button>
            </div>
            <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="sr-only" onChange={(event) => selectPhoto(event.target.files?.[0])} />
            <input ref={galleryInputRef} type="file" accept="image/*" className="sr-only" onChange={(event) => selectPhoto(event.target.files?.[0])} />
            {capture === "photo" ? (
              <div className="media-capture">
                {photoUrl ? <img src={photoUrl} alt={lang === "kk" ? "Таңдалған ағу фотосы" : "Выбранное фото утечки"} /> : <div className="capture-placeholder"><ImageIcon /><span>{lang === "kk" ? "Фото қосылмаған" : "Фото не добавлено"}</span></div>}
                <div className="capture-actions">
                  <Button variant="outline" size="sm" onClick={() => cameraInputRef.current?.click()}><Camera />{lang === "kk" ? "Түсіру" : "Снять"}</Button>
                  <Button variant="outline" size="sm" onClick={() => galleryInputRef.current?.click()}><ImageIcon />{lang === "kk" ? "Жүктеу" : "Загрузить"}</Button>
                </div>
              </div>
            ) : (
              <div className="media-capture audio-capture">
                {audioUrl && !isRecording ? <audio src={audioUrl} controls aria-label={lang === "kk" ? "Жазылған дыбыс" : "Записанный звук"} /> : <div className={`audio-status ${isRecording ? "recording" : ""}`}><span /><strong>{isRecording ? `${recordingSeconds} сек` : (lang === "kk" ? "Дыбыс жазуға дайын" : "Готово к записи")}</strong></div>}
                <Button variant={isRecording ? "destructive" : "outline"} size="sm" onClick={isRecording ? stopRecording : startRecording}>{isRecording ? <CircleDot /> : <Mic />}{isRecording ? (lang === "kk" ? "Тоқтату" : "Остановить") : (lang === "kk" ? "Жазуды бастау" : "Начать запись")}</Button>
              </div>
            )}
            {mediaError && <p className="media-error">{mediaError}</p>}
            <button className="mini-map" onClick={() => setPin(true)} aria-label="Place map pin">
              <span className="road road-a" /><span className="road road-b" />
              {pin ? <MapPin className="map-pin size-7" /> : <span className="map-prompt"><MapPin className="size-4" />{lang === "kk" ? "Нүктені белгілеу" : "Поставить метку"}</span>}
            </button>
            <textarea value={note} onChange={(event) => setNote(event.target.value)} maxLength={80} placeholder={lang === "kk" ? "Қысқаша сипаттама…" : "Короткое описание…"} className="report-note" />
            <Button onClick={next} disabled={!pin} className="h-11 w-full rounded-full bg-primary text-primary-foreground shadow-none">{lang === "kk" ? "AI талдауына жіберу" : "Отправить на AI-анализ"}<Sparkles /></Button>
          </motion.div>
        )}
        {step === 2 && (
          <motion.div key="two" className="phone-content" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -18 }}>
            <p className="phone-kicker">AI analysis · 4.2 sec</p>
            <h3>{lang === "kk" ? "Ағу ықтималдығы жоғары" : "Высокая вероятность утечки"}</h3>
            <div className="analysis-score"><span>87%</span><div><i /></div></div>
            <div className="metric"><span>{lang === "kk" ? "Болжамды ағын" : "Расход воды"}</span><strong>18–24 л/мин</strong></div>
            <div className="metric"><span>{lang === "kk" ? "Жақын өтінімдер" : "Похожих рядом"}</span><strong>6</strong></div>
            <div className="priority-box"><Radio className="size-4"/><span>{lang === "kk" ? "Ұсыныс: жоғары басымдық" : "Рекомендация: высокий приоритет"}</span></div>
            <Button onClick={next} className="h-11 w-full rounded-full bg-primary text-primary-foreground shadow-none">{lang === "kk" ? "Өтінімді растау" : "Подтвердить заявку"}<ArrowRight /></Button>
          </motion.div>
        )}
        {step === 3 && (
          <motion.div key="three" className="phone-content items-center justify-center text-center" initial={{ opacity: 0, scale: .94 }} animate={{ opacity: 1, scale: 1 }}>
            <div className="success-mark"><Check /></div>
            <p className="phone-kicker">AQ-2026-2420</p>
            <h3>{lang === "kk" ? "Өтінім қабылданды" : "Заявка принята"}</h3>
            <p className="text-sm text-muted-foreground">{lang === "kk" ? "«МАЭК» диспетчерлік қызметіне жіберілді. Мәртебе өзгергенде хабарлаймыз." : "Передано в диспетчерскую службу «МАЭК». Мы сообщим об изменении статуса."}</p>
            <Button variant="outline" onClick={reset} className="mt-4 rounded-full shadow-none">{lang === "kk" ? "Тағы бір өтінім" : "Новая заявка"}</Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Index() {
  const [lang, setLang] = useState<Lang>("kk");
  const [menu, setMenu] = useState(false);
  const [filter, setFilter] = useState<Severity | "all">("all");
  const [selected, setSelected] = useState(2419);
  const t = copy[lang];
  const visible = useMemo(() => filter === "all" ? incidents : incidents.filter((item) => item.severity === filter), [filter]);
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <main className="min-h-screen overflow-hidden bg-background text-foreground">
      <header className="site-header">
        <a href="#top" className="brand" aria-label="AQTA home"><span className="brand-drop"><Droplets /></span><span>Aqta</span></a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#how">{t.nav[0]}</a><a href="#services">{t.nav[1]}</a><a href="#ai">{t.nav[2]}</a>
        </nav>
        <div className="flex items-center gap-2">
          <div className="language-switch" aria-label="Language"><button onClick={() => setLang("kk")} className={lang === "kk" ? "active" : ""}>ҚАЗ</button><button onClick={() => setLang("ru")} className={lang === "ru" ? "active" : ""}>РУС</button></div>
          <Button variant="ghost" size="icon" onClick={() => setMenu(!menu)} className="mobile-menu text-primary-foreground hover:bg-primary-foreground/10" aria-label="Menu">{menu ? <X /> : <Menu />}</Button>
        </div>
        {menu && <nav className="mobile-nav"><a href="#how" onClick={() => setMenu(false)}>{t.nav[0]}</a><a href="#services" onClick={() => setMenu(false)}>{t.nav[1]}</a><a href="#ai" onClick={() => setMenu(false)}>{t.nav[2]}</a></nav>}
      </header>

      <section id="top" className="hero-section">
        <motion.div className="hero-copy" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .55 }}>
          <div className="loss-badge"><strong>25–30%</strong><span>{t.loss}</span></div>
          <h1>{t.titleA} <em>{t.titleB}</em></h1>
          <p className="hero-lead">{t.lead}</p>
          <div className="hero-actions"><RippleButton onClick={() => scrollTo("report-demo")}>{t.report}</RippleButton><RippleButton outline onClick={() => scrollTo("services")}>{t.map}</RippleButton></div>
          <button className="scroll-cue" onClick={() => scrollTo("how")}><ArrowDown />{t.how}</button>
        </motion.div>
        <motion.div className="phone-stage" initial={{ opacity: 0, y: 30, rotate: 2 }} animate={{ opacity: 1, y: 0, rotate: 0 }} transition={{ delay: .15, duration: .65 }}><div className="water-ring ring-one"/><div className="water-ring ring-two"/><PhoneDemo lang={lang} /></motion.div>
      </section>

      <section id="how" className="section-shell">
        <div className="section-heading"><p>{t.eyebrow}</p><h2>{t.how}</h2></div>
        <div className="steps-grid">
          {getHowCards(lang).map(({ num, title, text, icon: Icon }) => <article className="step-card" key={num}><div><span>{num}</span><Icon className="size-5" /></div><h3>{title}</h3><p>{text}</p></article>)}
        </div>
      </section>

      <section className="section-shell precedent-section">
        <div className="precedent-card"><p className="precedent-label">{t.precedent}</p><strong>1600+</strong><div><h2>{lang === "kk" ? "Ерте анықтау жұмыс істейді" : "Раннее обнаружение работает"}</h2><p>{lang === "kk" ? "2004 жылдан бері тұрақты акустикалық сенсорлар Лас-Вегас-Стрип астынан 1600-ден астам ағуды тапты. Aqta сол қағиданы арзанырақ іске асырады: сенсор желісін орнату тиімсіз аудандарда тұрғындардың дерегі мен AI бірге жұмыс істейді." : "С 2004 года постоянные акустические датчики нашли под Лас-Вегас-Стрип более 1600 утечек. Aqta следует тому же принципу дешевле: там, где сеть датчиков пока невыгодна, её заменяют сообщения жителей и AI."}</p></div></div>
      </section>

      <section id="ai" className="section-shell ai-section">
        <div className="section-heading"><p>Multimodal intelligence</p><h2>{t.ai}</h2></div>
        <div className="ai-grid">
          {getAiCards(lang).map(({ icon: Icon, title, text }) => <article className="ai-card" key={title}><span><Icon /></span><h3>{title}</h3><p>{text}</p><div className="signal-lines"><i/><i/><i/><i/></div></article>)}
        </div>
      </section>

      <section id="services" className="dispatcher-wrap">
        <div className="dispatcher-panel">
          <div className="dispatcher-top"><div><p>Dispatch console</p><h2>{t.dashboard}</h2></div><div className="summary-pill"><span>16 new</span><span>3 high priority</span><span>2 resolved</span></div></div>
          <div className="filter-row">{(["all", "high", "medium", "resolved"] as const).map((value) => <button key={value} className={filter === value ? "active" : ""} onClick={() => setFilter(value)}>{value === "all" ? (lang === "kk" ? "Барлығы" : "Все") : severityLabel[value]}</button>)}</div>
          <div className="dispatcher-grid">
            <div className="city-map" aria-label="Aktau incident map"><span className="coastline"/><span className="map-label label-one">КАСПИЙ ТЕҢІЗІ</span><span className="map-label label-two">AKTAU</span><span className="map-road map-road-a"/><span className="map-road map-road-b"/><span className="map-road map-road-c"/>{visible.map((item) => <button key={item.id} className={`incident-dot ${item.severity} ${selected === item.id ? "selected" : ""}`} style={{ left: item.x, top: item.y }} onClick={() => setSelected(item.id)} aria-label={`${item.district}: ${item.title}`}><span/></button>)}<div className="map-legend"><span><i className="high"/>High</span><span><i className="medium"/>Medium</span><span><i className="low"/>Low</span><span><i className="resolved"/>Resolved</span></div></div>
            <div className="ticket-list">{visible.map((item) => <button key={item.id} className={`ticket ${selected === item.id ? "active" : ""}`} onClick={() => setSelected(item.id)}><i className={item.severity}/><div><span>{item.district} · AQ-{item.id}</span><strong>{item.title}</strong><small>{item.meta}</small></div><ChevronRight /></button>)}</div>
          </div>
        </div>
      </section>

      <section className="section-shell now-section">
        <div className="section-heading"><p>September · 2026</p><h2>{t.now}</h2></div>
        <div className="now-grid">
          {[ ["13.09", "7 мкр", lang === "kk" ? "Құбыр жарылып, бірнеше үй мен мектеп сусыз қалды." : "Порыв оставил без воды несколько домов и школу."], ["09.09", lang === "kk" ? "Бүкіл қала" : "Весь город", lang === "kk" ? "Сорғы станциялары арасындағы магистральді қайта қосу үшін су тоқтатылды." : "Воду отключили для переподключения магистрали между насосными станциями."], [lang === "kk" ? "Жаз" : "Лето", lang === "kk" ? "Қайталанған кідіріс" : "Повторные задержки", lang === "kk" ? "Гидравликалық сынақтардан кейін ыстық суды қайтару бірнеше рет созылды." : "Возврат горячей воды после гидравлических испытаний неоднократно задерживался."] ].map(([date, place, text]) => <article className="now-card" key={date}><span>{date}</span><h3>{place}</h3><p>{text}</p></article>)}
        </div>
      </section>

      <footer><div><a href="#top" className="brand footer-brand"><span className="brand-drop"><Droplets /></span><span>Aqta</span></a><p>{t.prototype}</p></div><div className="contacts"><span>{lang === "kk" ? "Су диспетчері" : "Диспетчер воды"}: <a href="tel:87292570840">+7 (7292) 57-08-40</a></span><span>{lang === "kk" ? "Газ апаты" : "Аварийная газовая"}: <a href="tel:104">104</a></span></div><p className="footer-tagline">{t.tagline}</p></footer>
    </main>
  );
}